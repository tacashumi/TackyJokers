--- STEAMODDED HEADER
--- MOD_NAME: Tacky Jokers
--- MOD_ID: TJOKERS
--- MOD_AUTHOR: [Tacashumi, fey]
--- MOD_DESCRIPTION: Vanilla-esque Jokers that encourage non-meta playstyles
--- BADGE_COLOR: 777FFF
--- PREFIX: tac
----------------------------------------------
------------MOD CODE -------------------------

--Wasteful Joker
SMODS.Joker {
    key = 'wasteful',
    loc_txt = { name = 'Wasteful Joker',
        text = { 'Gain {C:mult}+#1#{} Mult Per {C:discard}Discard{} Used',
            '{C:mult}-#2#{} Mult Per Played {C:hand}Hand{}',
            '{s:0.8,C:inactive}(Currently {C:mult,s:0.8}+#3#{C:inactive,s:0.8} Mult)' } },
    cost = 5,
    order = 1,
    atlas = 'wasteful',
    rarity = 1,
    discovered = true,
    blueprint_compat = true,
    config = { extra = { mult = 0, mult_gain = 1, mult_loss = 1 } },
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.mult_gain,
                center.ability.extra.mult_loss,
                center.ability.extra.mult
            }
        }
    end,
    calculate = function(card, card, context)
        if context.before and context.cardarea == G.jokers and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult - card.ability.extra.mult_loss
            return {
                message = localize { type = 'variable', key = 'a_mult_minus', vars = { card.ability.extra.mult_loss } },
                colour = G.C.RED,
            }
        end
        if context.pre_discard and context.cardarea == G.jokers and not context.blueprint then
            card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
            return {
                message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult_gain } },
                colour = G.C.RED,
            }
        end
        if context.joker_main and card.ability.extra.mult > 0 then
            return {
                mult = card.ability.extra.mult
            }
        end
    end
}

SMODS.Atlas {
    key = 'wasteful',
    path = 'Wasteful_Joker.png',
    px = 71,
    py = 95
}

--Crumbly Joker
SMODS.Joker {
    key = 'crumbly',
    loc_txt = { name = 'Crumbly Joker',
        text = { '{C:chips}+#1#{} Chip when any Card is {C:attention}Scored',
            '{s:0.8,C:inactive}(Currently {s:0.8,C:chips}+#2#{s:0.8,C:inactive} Chips)' } },
    cost = 7,
    atlas = 'crumbly',
    rarity = 1,
    order = 2,
    blueprint_compat = true,
    config = { extra = { chips = 0, chip_mod = 1 } },
    discovered = true,
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.chip_mod,
                center.ability.extra.chips
            }
        }
    end,
    calculate = function(card, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.chip_mod
            return {
                message = '+' .. card.ability.extra.chip_mod .. ' Chip',
                message_card = card,
                colour = G.C.CHIPS
            }
        end
        if context.joker_main and card.ability.extra.chips > 0 then
            return {
                chip_mod = card.ability.extra.chips,
                message = '+' .. card.ability.extra.chips .. ' Chips',
                colour = G.C.CHIPS
            }
        end
    end
}

SMODS.Atlas {
    key = 'crumbly',
    path = 'Crumbly_Joker.png',
    px = 71,
    py = 95
}

--Tacky Joker
SMODS.Joker {
    key = 'tacky',
    atlas = 'tacky',
    order = 3,
    loc_txt = { name = 'Tacky Joker',
        text = {
            'Gain {C:money}$#1#{} on Scoring any {C:attention}Odd',
            'Numbered Cards {C:inactive}(A, 3, 5, 7, 9)'
        } },
    discovered = true,
    cost = 10,
    rarity = 2,
    blueprint_compat = true,
    config = { extra = { dollars = 1 } },
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.dollars
            }
        }
    end,
    calculate = function(card, card, context)
        if context.individual and context.cardarea == G.play then
            local id = context.other_card.base.id
            if id == 14 or id == 3 or id == 5 or id == 7 or id == 9 then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}

SMODS.Atlas {
    key = 'tacky',
    path = 'Tacky_Joker.png',
    px = 71,
    py = 95
}

--The Closet
SMODS.Joker {
    key = 'closet',
    atlas = 'closet',
    rarity = 2,
    cost = 4,
    blueprint_compat = false,
    loc_txt = { name = 'The Closet',
        text = {
            'After Playing #1# {C:inactive}(#2#){} {C:attention}Straights,',
            'sell this card to add {C:dark_edition}Polychrome',
            'to a random {C:attention}Joker'
        } },
    config = { extra = { req = 3, cur = 0 } },
    discovered = true,
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.req,
                center.ability.extra.cur
            }
        }
    end,
    calculate = function(card, card, context)
        if context.before and context.scoring_name == 'Straight' then
            local eval = function(card)
                return (card.ability.extra.cur >= card.ability.extra.req)
            end
            juice_card_until(card, eval, true)
            card.ability.extra.cur = card.ability.extra.cur + 1
            return {
                message = card.ability.extra.cur .. '...',
                colour = G.C.DARK_EDITION
            }
        end
        if context.selling_card then
            if card.ability.extra.cur >= card.ability.extra.req then
                local editionless = {}
                for i, v in ipairs(G.jokers.cards) do
                    if v.edition == nil then
                        table.insert(editionless, v)
                    end
                end
                if #editionless > 0 then
                    local _card = pseudorandom_element(editionless, pseudoseed('closet'))
                    _card:set_edition('e_polychrome')
                end
            end
        end
    end
}

SMODS.Atlas {
    key = 'closet',
    path = 'The_Closet.png',
    px = 71,
    py = 95
}

--Hack-er

SMODS.Joker {
    key = 'hacker',
    atlas = 'hack-er',
    loc_txt = { name = 'Hack-er',
        text = {
            'Every played {C:attention}2, 3, 4 and 5{} permanently',
            'gains {C:mult}+#1#{} Mult when scored' } },
    cost = 6,
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.bonus
            }
        }
    end,
    rarity = 2,
    discovered = true,
    config = { extra = { bonus = 1 } },
    calculate = function(card, card, context)
        if context.individual and context.cardarea == G.play then
            local _card = context.other_card
            if _card.base.id == 2 or _card.base.id == 3 or _card.base.id == 4 or _card.base.id == 5 then
                _card.ability.perma_mult = _card.ability.perma_mult + card.ability.extra.bonus
                return {
                    message = localize('k_upgrade_ex'), colour = G.C.MULT
                }
            end
        end
    end
}

SMODS.Atlas {
    key = 'hack-er',
    path = 'j_hack_er.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'mirror',
    atlas = 'mirror',
    blueprint_compat = true,
    discovered = true,
    loc_txt = { name = 'The Mirror',
        text = {
            'If hand contains {C:attention}5{} scoring',
            'cards, retrigger each card',
            '{C:attention}#1#{} time' } },
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.ret
            }
        }
    end,
    config = { extra = { ret = 1 } },
    cost = 11,
    rarity = 3,
    calculate = function(card, card, context)
        if context.repetition and context.cardarea == G.play then
            if #G.play.cards == 5 then
                return {
                    message = localize('k_again_ex'),
                    repetitions = card.ability.extra.ret,
                    card = card
                }
            end
        end
    end
}

SMODS.Atlas {
    key = 'mirror',
    path = 'The_Mirror.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'conquest',
    cost = 9,
    rarity = 3,
    atlas = 'conquest',
    loc_txt = { name = 'Conquest',
        text = {
            'The {C:attention}lowest{} ranked played card',
            'has its rank upgraded by {C:attention}1{},',
            'unless its an {C:attention}Ace' } },
    blueprint_compat = false,
    calculate = function(card, card, context)
        if context.before then
            local min = 14
            local minsuit = nil
            local mincard = nil
            for i, v in ipairs(G.play.cards) do
                if v.base.id < min then
                    min = v.base.id
                    mincard = v
                    minsuit = string.sub(v.base.suit, 1, 1)
                end
            end
            if min < 14 then
                min = min + 1
                if min == 10 then
                    min = 'T'
                elseif min == 11 then
                    min = 'J'
                elseif min == 12 then
                    min = 'Q'
                elseif min == 13 then
                    min = 'K'
                elseif min == 14 then
                    min = 'A'
                end
                mincard:set_base(G.P_CARDS[minsuit .. '_' .. (min)])
            end
        end
    end
}

SMODS.Atlas {
    key = 'conquest',
    path = 'Conquest.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'sprayon',
    atlas = 'sprayon',
    loc_txt = {
        name = 'Spray-On Joker',
        text = { 'Gain {C:mult}+#1#{} Mult when',
            'buying a {C:attention}Joker',
            '{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)' } },
    cost = 4,
    rarity = 1,
    discovered = true,
    blueprint_compat = true,
    config = { extra = { mult = 0, mult_gain = 5 } },
    loc_vars = function(card, info_queue, center)
        return {
            vars = {
                center.ability.extra.mult_gain,
                center.ability.extra.mult
            }
        }
    end,
    calculate = function(card, card, context)
        if context.buying_card and not context.blueprint then
            if context.card.config.center.set == 'Joker' then
                card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
                return {
                    message = localize('k_upgrade_ex'), colour = G.C.MULT
                }
            end
        end
        if context.joker_main then
            return {
                mult = card.ability.extra.mult
            }
        end
    end
}

SMODS.Atlas {
    key = 'sprayon',
    path = 'Spray-On_Joker.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'starving',
    atlas = 'starving',
    rarity = 2,
    cost = 6,
    discovered = true,
    blueprint_compat = true,
    loc_txt = { name = 'Starving Joker',
        text = { '{C:white,X:mult}+#1#{} Xmult for each {C:spades}spade',
            '{C:attention} face{} card in deck, {C:attention}destroys',
            '{C:spades}spade{C:attention} face{} cards when scored',
            '{C:inactive}(Currently {C:white,X:mult}X#2#{C:inactive} Mult)' } },
    loc_vars = function(card, info_queue, center)
        if G.playing_cards ~= nil then
            local count = 0
            for i, v in ipairs(G.playing_cards) do
                if v:is_face() == true and v.base.suit == 'Spades' then
                    count = count + 1
                end
            end
            return {
                vars = {
                    center.ability.extra.offset,
                    1 + (count * center.ability.extra.offset)
                }
            }
        else
            return {
                vars = {
                    'nothing...',
                    'starving...'
                }
            }
        end
    end,
    config = { extra = { Xmult = 1, offset = 0.5 } },
    calculate = function(card, card, context)
        if context.joker_main then
            local count = 0
            for i, v in ipairs(G.playing_cards) do
                if v:is_face() == true and v.base.suit == 'Spades' then
                    count = count + 1
                end
            end
            card.ability.extra.Xmult = 1 + count * card.ability.extra.offset
            return {
                Xmult = card.ability.extra.Xmult
            }
        end
        if context.destroy_card and context.cardarea == G.play and not context.blueprint then
            if context.destroy_card:is_face() == true and context.destroy_card.base.suit == 'Spades' then
                return {
                    remove = true,
                    message = 'Death!'
                }
            end
        end
    end
}

SMODS.Atlas {
    key = 'starving',
    path = 'Starving_Joker.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'spectro',
    cost = 10,
    rarity = 2,
    atlas = 'spectro',
    blueprint_compat = true,
    loc_txt = { name = 'Spectromancer',
        text = {
            'On selecting a {C:attention}Blind,',
            '{C:attention}destroy{} all consumables and',
            '{C:attention}create{} a {C:spectral}Spectral{} card' } },
    calculate = function(card, card, context)
        if context.setting_blind then
            for i, v in ipairs(G.consumeables.cards) do
                v:start_dissolve()
            end
            SMODS.add_card({ set = 'Spectral', area = G.consumeables })
        end
        if context.setting_blind and context.blueprint then
            SMODS.add_card({ set = 'Spectral', area = G.consumeables })
        end
    end,
    draw = function(self,card,layer)
        card.children.center:draw_shader('booster', nil, card.ARGS.send_to_shader)
    end
}

SMODS.Atlas {
    key = 'spectro',
    path = 'Spectromancer.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'ghost',
    discovered = true,
    loc_txt = { name = 'Ghost Clown',
        text = {
            '{C:white,X:chips}X#1#{} Chips per {C:spectral}Spectral',
            'card used this run',
            '{C:inactive}(Currently {C:white,X:chips}X#2#{C:inactive} Chips)'
        } },
    atlas = 'ghost',
    rarity = 2,
    cost = 8,
    blueprint_compat = true,
    pos = { x = 1, y = 0},
    soul_pos = { x = 0, y = 0,
        draw = function(card, scale_mod, rotate_mod)
            card.hover_tilt = card.hover_tilt * 1.5
            card.children.floating_sprite:draw_shader('hologram', nil, card.ARGS.send_to_shader, nil,
                card.children.center, 2 * scale_mod, 2 * rotate_mod)
            card.hover_tilt = card.hover_tilt / 1.5
        end
    },
    loc_vars = function(self,info_queue,center)
        local xchips = 1
        if G.GAME.consumeable_usage_total ~= nil and G.GAME.consumeable_usage_total.spectral ~= nil then
                xchips = 1 + (G.GAME.consumeable_usage_total.spectral * center.ability.extra.mod)
            end
        return {vars = {
            center.ability.extra.mod,
            xchips
        }}
    end,
    config = {extra = {Xchips = 1, mod = 0.5}},
    draw = function(self,card,layer)
        card.children.center:draw_shader('booster', nil, card.ARGS.send_to_shader)
    end,
    calculate = function(self,card,context)
        if context.joker_main then
            if G.GAME.consumeable_usage_total ~= nil and G.GAME.consumeable_usage_total.spectral ~= nil then
                card.ability.extra.Xchips = 1 + (G.GAME.consumeable_usage_total.spectral * card.ability.extra.mod)
            end
            return {
                xchips = card.ability.extra.Xchips
            }
        end
    end
}

SMODS.Atlas {
    key = 'ghost',
    path = 'Ghost_Clown.png',
    px = 71,
    py = 95
}

SMODS.Joker {
    key = 'conspirator',
    atlas = 'consp',
    blueprint_compat = false,
    discovered = true,
    loc_txt = {
        name = 'Conspirator',
        text = {'All scored cards on the',
                '{C:attention}final hand{} of the round',
                'become {C:dark_edition}foil{} cards'}},
    cost = 5,
    rarity = 1,
    calculate = function(self,card,context)
        if context.before and G.GAME.current_round.hands_left == 0 then
            for i,v in ipairs(G.play.cards) do
                if not v.debuff then
                    v:set_edition('e_foil')
                end
            end
        end
    end
}

SMODS.Atlas {
    key = 'consp',
    path = 'Conspirator.png',
    px = 71,
    py = 95
}

-------------------------------------------------
------------MOD CODE END----------------------
